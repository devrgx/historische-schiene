import type { Metadata } from "next";
import {
  CalendarDays,
  CircleAlert,
  Clock3,
  Eye,
  FileCheck2,
  Mail,
  ShieldCheck,
  UserRound,
} from "lucide-react";
import Link from "next/link";

import { PageHeader } from "@/components/ui/page-header";
import { prisma } from "@/lib/prisma";

export const metadata: Metadata = {
  title: "Mitgliedsanträge",
  description:
    "Übersicht und Bearbeitung eingegangener Mitgliedsanträge.",
};

export const dynamic = "force-dynamic";

const statusConfig = {
  PENDING: {
    label: "Eingegangen",
    className:
      "border-amber-400/30 bg-amber-400/10 text-amber-200",
  },
  IN_REVIEW: {
    label: "In Prüfung",
    className:
      "border-blue-400/30 bg-blue-400/10 text-blue-200",
  },
  APPROVED: {
    label: "Genehmigt",
    className:
      "border-emerald-400/30 bg-emerald-400/10 text-emerald-200",
  },
  REJECTED: {
    label: "Abgelehnt",
    className:
      "border-red-400/30 bg-red-400/10 text-red-200",
  },
  WITHDRAWN: {
    label: "Zurückgezogen",
    className:
      "border-line bg-page-soft text-subtle",
  },
} as const;

const membershipTypeLabels = {
  REGULAR: "Ordentlich",
  REDUCED: "Ermäßigt",
  SUPPORTING: "Fördermitglied",
} as const;

export default async function AdminApplicationsPage() {
  const applications =
    await prisma.membershipApplication.findMany({
      orderBy: [
        {
          createdAt: "desc",
        },
      ],
      include: {
        reviewedBy: {
          select: {
            displayName: true,
          },
        },
        member: {
          select: {
            membershipNumber: true,
          },
        },
      },
    });

  const pendingCount = applications.filter(
    (application) =>
      application.status === "PENDING",
  ).length;

  const reviewCount = applications.filter(
    (application) =>
      application.status === "IN_REVIEW",
  ).length;

  const approvedCount = applications.filter(
    (application) =>
      application.status === "APPROVED",
  ).length;

  return (
    <>
      <PageHeader
        eyebrow="Mitgliederverwaltung"
        title="Mitgliedsanträge"
        description="Hier können eingegangene Mitgliedsanträge geprüft und später genehmigt oder abgelehnt werden."
      />

      <section className="border-b border-line bg-page-soft">
        <div className="site-container py-8">
          <div className="flex gap-4 rounded-2xl border border-accent-border bg-accent-soft p-5">
            <CircleAlert
              size={22}
              className="mt-0.5 shrink-0 text-accent-light"
            />

            <div>
              <h2 className="font-semibold text-content">
                Adminbereich noch ohne Zugriffsschutz
              </h2>

              <p className="mt-2 text-sm leading-7 text-muted">
                Diese Seite dient zunächst der lokalen Entwicklung.
                Sobald Login und Rollenprüfung eingerichtet sind,
                wird der Zugriff auf berechtigte Personen beschränkt.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="section-spacing">
        <div className="site-container">
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            <StatusCard
              label="Alle Anträge"
              value={applications.length}
              icon={FileCheck2}
            />

            <StatusCard
              label="Eingegangen"
              value={pendingCount}
              icon={Clock3}
            />

            <StatusCard
              label="In Prüfung"
              value={reviewCount}
              icon={Eye}
            />

            <StatusCard
              label="Genehmigt"
              value={approvedCount}
              icon={ShieldCheck}
            />
          </div>

          {applications.length > 0 ? (
            <div className="mt-10 overflow-hidden rounded-2xl border border-line bg-surface">
              <div className="overflow-x-auto">
                <table className="w-full min-w-[70rem] text-left">
                  <thead className="border-b border-line bg-page-soft">
                    <tr className="text-sm text-muted">
                      <th className="px-5 py-4 font-semibold">
                        Antragsteller
                      </th>

                      <th className="px-5 py-4 font-semibold">
                        Mitgliedsform
                      </th>

                      <th className="px-5 py-4 font-semibold">
                        Alter
                      </th>

                      <th className="px-5 py-4 font-semibold">
                        Eingang
                      </th>

                      <th className="px-5 py-4 font-semibold">
                        Status
                      </th>

                      <th className="px-5 py-4 font-semibold">
                        Mitgliedsnummer
                      </th>

                      <th className="px-5 py-4 font-semibold">
                        Aktion
                      </th>
                    </tr>
                  </thead>

                  <tbody className="divide-y divide-line">
                    {applications.map((application) => {
                      const status =
                        statusConfig[application.status];

                      const age = calculateAge(
                        application.birthDate,
                      );

                      return (
                        <tr
                          key={application.id}
                          className="transition hover:bg-surface-hover"
                        >
                          <td className="px-5 py-5">
                            <div className="flex items-start gap-3">
                              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-accent-soft text-accent-light">
                                <UserRound size={19} />
                              </span>

                              <div>
                                <p className="font-semibold text-content">
                                  {application.firstName}{" "}
                                  {application.lastName}
                                </p>

                                <a
                                  href={`mailto:${application.email}`}
                                  className="mt-1 flex items-center gap-1.5 text-sm text-muted transition hover:text-accent-light"
                                >
                                  <Mail size={14} />
                                  {application.email}
                                </a>
                              </div>
                            </div>
                          </td>

                          <td className="px-5 py-5 text-sm text-muted">
                            {
                              membershipTypeLabels[
                                application.membershipType
                              ]
                            }
                          </td>

                          <td className="px-5 py-5">
                            <div className="text-sm">
                              <p className="font-medium text-content">
                                {age} Jahre
                              </p>

                              {application.isMinor ? (
                                <p className="mt-1 text-xs text-amber-200">
                                  Minderjährig
                                </p>
                              ) : null}
                            </div>
                          </td>

                          <td className="px-5 py-5">
                            <div className="flex items-center gap-2 text-sm text-muted">
                              <CalendarDays
                                size={15}
                                className="shrink-0"
                              />

                              {formatDate(
                                application.createdAt,
                              )}
                            </div>
                          </td>

                          <td className="px-5 py-5">
                            <span
                              className={`inline-flex rounded-full border px-3 py-1 text-xs font-semibold ${status.className}`}
                            >
                              {status.label}
                            </span>
                          </td>

                          <td className="px-5 py-5 text-sm text-muted">
                            {application.member
                              ?.membershipNumber ??
                              "Noch nicht vergeben"}
                          </td>

                          <td className="px-5 py-5">
                            <Link
                              href={`/admin/antraege/${application.id}`}
                              className="inline-flex items-center gap-2 rounded-lg border border-line bg-page-soft px-4 py-2 text-sm font-semibold text-content transition hover:border-accent-border hover:text-accent-light"
                            >
                              <Eye size={16} />
                              Öffnen
                            </Link>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <div className="surface-card mt-10 px-6 py-16 text-center">
              <FileCheck2
                size={42}
                className="mx-auto text-accent-light"
              />

              <h2 className="mt-6 text-2xl font-bold text-content">
                Noch keine Anträge
              </h2>

              <p className="mx-auto mt-4 max-w-xl leading-8 text-muted">
                Sobald ein Mitgliedsantrag über das Onlineformular
                abgesendet wurde, erscheint er hier automatisch.
              </p>

              <Link
                href="/mitmachen/antrag"
                className="mt-7 inline-flex items-center justify-center rounded-lg bg-accent px-5 py-3 text-sm font-semibold text-white transition hover:bg-accent-light"
              >
                Testantrag ausfüllen
              </Link>
            </div>
          )}
        </div>
      </section>
    </>
  );
}

type StatusCardProps = {
  label: string;
  value: number;
  icon: typeof FileCheck2;
};

function StatusCard({
  label,
  value,
  icon: Icon,
}: StatusCardProps) {
  return (
    <article className="surface-card p-6">
      <div className="flex items-start justify-between gap-4">
        <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-accent-soft text-accent-light">
          <Icon size={21} />
        </span>

        <span className="text-3xl font-bold text-content">
          {value}
        </span>
      </div>

      <p className="mt-5 text-sm font-medium text-muted">
        {label}
      </p>
    </article>
  );
}

function calculateAge(
  birthDate: Date,
): number {
  const today = new Date();

  let age =
    today.getFullYear() -
    birthDate.getFullYear();

  const birthdayOccurred =
    today.getMonth() > birthDate.getMonth() ||
    (today.getMonth() === birthDate.getMonth() &&
      today.getDate() >= birthDate.getDate());

  if (!birthdayOccurred) {
    age -= 1;
  }

  return age;
}

function formatDate(date: Date): string {
  return new Intl.DateTimeFormat("de-DE", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  }).format(date);
}